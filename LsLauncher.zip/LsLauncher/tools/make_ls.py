# tools/make_ls.py
"""Empacota uma pasta (com ls.json na raiz) em um arquivo .ls (ZIP).

Uso: python3 tools/make_ls.py samples/hello_pack samples/hello_pack.ls
"""
import json
import pathlib
import sys
import zipfile


def build(source_dir: pathlib.Path, output_file: pathlib.Path) -> None:
    manifest_path = source_dir / "ls.json"
    if not manifest_path.is_file():
        raise SystemExit(f"ls.json não encontrado em {source_dir}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise SystemExit(f"ls.json inválido: {error}")
    for entry in manifest.get("files", []):
        if not (source_dir / entry["from"]).exists():
            raise SystemExit(f"'from' não existe: {entry['from']}")

    with zipfile.ZipFile(output_file, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(source_dir).as_posix())
    print(f"Gerado: {output_file}")


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("Uso: make_ls.py <pasta> <saida.ls>")
    build(pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]))


if __name__ == "__main__":
    main()
