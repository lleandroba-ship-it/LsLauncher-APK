plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Pacote do jogo-alvo. Troque com: gradle assembleDebug -PgamePackage=com.outro.jogo
val gamePackage: String = providers.gradleProperty("gamePackage").orElse("com.mojang.minecraftpe").get()
val ciRunNumber: Int = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "com.lslauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lslauncher"
        minSdk = 24
        targetSdk = 34
        versionCode = ciRunNumber
        versionName = "1.0.$ciRunNumber"

        buildConfigField("String", "GAME_PACKAGE", "\"$gamePackage\"")
        manifestPlaceholders["gamePackage"] = gamePackage
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
