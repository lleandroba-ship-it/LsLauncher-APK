// app/src/main/java/com/lslauncher/LauncherApp.kt
package com.lslauncher

import android.app.Application
import android.content.Context
import com.lslauncher.mods.GameSync
import com.lslauncher.mods.LauncherSettings
import com.lslauncher.mods.ModImporter
import com.lslauncher.mods.ModRepository
import java.io.File

class LauncherApp : Application() {
    lateinit var repository: ModRepository
        private set
    lateinit var importer: ModImporter
        private set
    lateinit var gameSync: GameSync
        private set
    lateinit var settings: LauncherSettings
        private set

    override fun onCreate() {
        super.onCreate()
        repository = ModRepository(filesDir)
        repository.cleanLeftovers()
        importer = ModImporter(this, repository)
        gameSync = GameSync(this, repository, File(filesDir, "game_install.json"))
        settings = LauncherSettings(this)
    }
}

val Context.launcherApp: LauncherApp
    get() = applicationContext as LauncherApp
