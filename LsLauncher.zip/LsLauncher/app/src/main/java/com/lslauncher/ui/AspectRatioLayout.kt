// app/src/main/java/com/lslauncher/ui/AspectRatioLayout.kt
package com.lslauncher.ui

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import com.lslauncher.R

/** Mantém o conteúdo na proporção da arte (sem distorcer) e centraliza, deixando o resto preto. */
class AspectRatioLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    private val aspectRatio: Float

    init {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.AspectRatioLayout)
        val ratio = try {
            typedArray.getFloat(R.styleable.AspectRatioLayout_aspectRatio, DEFAULT_RATIO)
        } finally {
            typedArray.recycle()
        }
        aspectRatio = ratio
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val availableWidth = View.MeasureSpec.getSize(widthMeasureSpec)
        val availableHeight = View.MeasureSpec.getSize(heightMeasureSpec)
        if (availableWidth == 0 || availableHeight == 0 || aspectRatio <= 0f) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
            return
        }

        var width = availableWidth
        var height = (width / aspectRatio).toInt()
        if (height > availableHeight) {
            height = availableHeight
            width = (height * aspectRatio).toInt()
        }
        super.onMeasure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY),
        )
    }

    private companion object {
        const val DEFAULT_RATIO = 16f / 9f
    }
}
