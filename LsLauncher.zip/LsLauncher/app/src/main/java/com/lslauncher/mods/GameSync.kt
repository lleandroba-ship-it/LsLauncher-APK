// app/src/main/java/com/lslauncher/mods/GameSync.kt
package com.lslauncher.mods

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException

class GameSyncException(message: String) : Exception(message)

/**
 * Faz o jogo enxergar exatamente os mods LIGADOS: copia para a pasta do jogo o que falta
 * e remove tudo que o launcher instalou antes e não deve mais estar lá.
 */
class GameSync(
    private val context: Context,
    private val repository: ModRepository,
    private val recordFile: File,
) {
    private data class InstalledRecord(
        val stampMillis: Long,
        val destinations: List<String>,
    )

    private val lock = Any()

    fun hasInstalledMods(): Boolean {
        synchronized(lock) {
            return loadRecords().isNotEmpty()
        }
    }

    fun sync(treeUri: Uri, enabledMods: List<ModInfo>) {
        synchronized(lock) {
            try {
                runSync(treeUri, enabledMods)
            } catch (e: IOException) {
                throw GameSyncException("Falha de E/S: ${e.message}")
            } catch (e: SecurityException) {
                throw GameSyncException("Sem permissão na pasta do jogo. Selecione-a de novo em MODS.")
            } catch (e: IllegalArgumentException) {
                throw GameSyncException("Pasta do jogo inválida. Selecione-a de novo em MODS.")
            } catch (e: UnsupportedOperationException) {
                throw GameSyncException("A pasta escolhida não permite escrita.")
            }
        }
    }

    private fun runSync(treeUri: Uri, enabledMods: List<ModInfo>) {
        val root = DocumentFile.fromTreeUri(context, treeUri)
        if (root == null || !root.exists() || !root.canWrite()) {
            throw GameSyncException("Sem acesso à pasta do jogo. Selecione-a de novo em MODS.")
        }
        assertNoConflicts(enabledMods)

        val previous = loadRecords()
        val enabledById = enabledMods.associateBy { it.id }
        val kept = LinkedHashMap<String, InstalledRecord>()

        for ((id, record) in previous) {
            val mod = enabledById[id]
            val upToDate = mod != null &&
                mod.importedAtMillis == record.stampMillis &&
                record.destinations.all { findRelative(root, it) != null }
            if (upToDate) {
                kept[id] = record
            } else {
                for (destination in record.destinations) {
                    if (!deleteRelative(root, destination)) {
                        throw GameSyncException("Não foi possível remover $destination do jogo")
                    }
                }
            }
        }
        saveRecords(kept)

        for (mod in enabledMods) {
            if (kept.containsKey(mod.id)) continue
            kept[mod.id] = installMod(root, mod)
            saveRecords(kept)
        }
    }

    private fun assertNoConflicts(mods: List<ModInfo>) {
        val owners = HashMap<String, String>()
        for (mod in mods) {
            for (target in mod.manifest.targets) {
                val owner = owners.put(target.destination, mod.id)
                if (owner != null) {
                    throw GameSyncException("Conflito: '$owner' e '${mod.id}' escrevem em ${target.destination}")
                }
            }
        }
    }

    private fun installMod(root: DocumentFile, mod: ModInfo): InstalledRecord {
        val modDirectory = repository.modDirectory(mod.id)
        val created = ArrayList<String>()
        try {
            for (target in mod.manifest.targets) {
                if (findRelative(root, target.destination) != null) {
                    throw GameSyncException("${target.destination} já existe no jogo e não pertence ao launcher")
                }
                val source = File(modDirectory, target.source)
                if (!source.exists()) {
                    throw GameSyncException("Arquivo do mod ausente: ${target.source}. Reimporte '${mod.name}'.")
                }
                val segments = target.destination.split('/')
                val parent = ensureDirectory(root, segments.dropLast(1))
                created += target.destination
                copyInto(source, parent, segments.last())
            }
        } catch (e: Exception) {
            // Desfazer é "melhor esforço": o erro original é o que importa para quem chamou.
            for (destination in created) deleteRelative(root, destination)
            throw e
        }
        return InstalledRecord(
            stampMillis = mod.importedAtMillis,
            destinations = created,
        )
    }

    private fun findRelative(root: DocumentFile, path: String): DocumentFile? {
        var current: DocumentFile = root
        for (segment in path.split('/')) {
            current = current.findFile(segment) ?: return null
        }
        return current
    }

    private fun deleteRelative(root: DocumentFile, path: String): Boolean {
        val document = findRelative(root, path) ?: return true
        return document.delete() || !document.exists()
    }

    private fun ensureDirectory(root: DocumentFile, segments: List<String>): DocumentFile {
        var current = root
        for (segment in segments) {
            val existing = current.findFile(segment)
            current = when {
                existing == null -> current.createDirectory(segment)
                    ?: throw GameSyncException("Não foi possível criar a pasta $segment no jogo")
                existing.isDirectory -> existing
                else -> throw GameSyncException("$segment existe no jogo mas não é uma pasta")
            }
        }
        return current
    }

    private fun createFile(parent: DocumentFile, name: String): DocumentFile {
        val document = parent.createFile("application/octet-stream", name)
            ?: throw GameSyncException("Não foi possível criar $name no jogo")
        if (document.name != name && !document.renameTo(name)) {
            throw GameSyncException("O provedor de arquivos alterou o nome de $name")
        }
        return document
    }

    private fun copyInto(source: File, parent: DocumentFile, name: String) {
        if (source.isDirectory) {
            val directory = parent.createDirectory(name)
                ?: throw GameSyncException("Não foi possível criar a pasta $name no jogo")
            val children = source.listFiles() ?: throw IOException("Não foi possível listar ${source.name}")
            for (child in children.sortedBy { it.name }) copyInto(child, directory, child.name)
            return
        }
        val document = createFile(parent, name)
        val output = context.contentResolver.openOutputStream(document.uri, "w")
            ?: throw GameSyncException("Não foi possível escrever $name no jogo")
        output.use { sink -> source.inputStream().use { it.copyTo(sink) } }
    }

    private fun loadRecords(): Map<String, InstalledRecord> {
        if (!recordFile.isFile) return emptyMap()
        return try {
            val mods = JSONObject(recordFile.readText(Charsets.UTF_8)).getJSONObject("mods")
            val records = LinkedHashMap<String, InstalledRecord>()
            for (id in mods.keys()) {
                val entry = mods.getJSONObject(id)
                records[id] = InstalledRecord(
                    stampMillis = entry.getLong("stamp"),
                    destinations = entry.getJSONArray("destinations").toStringList(),
                )
            }
            records
        } catch (e: JSONException) {
            Log.w(TAG, "game_install.json corrompido; registro descartado", e)
            emptyMap()
        } catch (e: IOException) {
            Log.w(TAG, "game_install.json ilegível; registro descartado", e)
            emptyMap()
        }
    }

    private fun saveRecords(records: Map<String, InstalledRecord>) {
        val mods = JSONObject()
        for ((id, record) in records) {
            mods.put(
                id,
                JSONObject()
                    .put("stamp", record.stampMillis)
                    .put("destinations", JSONArray(record.destinations)),
            )
        }
        writeTextAtomically(recordFile, JSONObject().put("mods", mods).toString())
    }

    private fun JSONArray.toStringList(): List<String> = (0 until length()).map { getString(it) }

    private companion object {
        const val TAG = "GameSync"
    }
}
