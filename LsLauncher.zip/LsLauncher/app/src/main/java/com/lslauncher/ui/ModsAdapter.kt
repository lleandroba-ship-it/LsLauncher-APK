// app/src/main/java/com/lslauncher/ui/ModsAdapter.kt
package com.lslauncher.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lslauncher.R
import com.lslauncher.databinding.ItemModBinding
import com.lslauncher.mods.ModInfo

private object ModDiffCallback : DiffUtil.ItemCallback<ModInfo>() {
    override fun areItemsTheSame(oldItem: ModInfo, newItem: ModInfo): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: ModInfo, newItem: ModInfo): Boolean = oldItem == newItem
}

class ModsAdapter(
    private val onToggle: (ModInfo) -> Unit,
    private val onDelete: (ModInfo) -> Unit,
) : ListAdapter<ModInfo, ModsAdapter.ModViewHolder>(ModDiffCallback) {

    class ModViewHolder(val binding: ItemModBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ModViewHolder {
        val binding = ItemModBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ModViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ModViewHolder, position: Int) {
        val mod = getItem(position)
        val context = holder.itemView.context
        val statusText = context.getString(if (mod.enabled) R.string.status_on else R.string.status_off)
        val statusColor = if (mod.enabled) R.color.status_on else R.color.status_off

        with(holder.binding) {
            modName.text = mod.name
            modStatus.text = context.getString(R.string.mod_status_format, statusText, mod.manifest.version)
            modStatus.setTextColor(ContextCompat.getColor(context, statusColor))
            toggleButton.setText(if (mod.enabled) R.string.action_turn_off else R.string.action_turn_on)
            toggleButton.setOnClickListener { onToggle(mod) }
            deleteButton.setOnClickListener { onDelete(mod) }
            root.setOnClickListener { onToggle(mod) }
        }
    }
}
