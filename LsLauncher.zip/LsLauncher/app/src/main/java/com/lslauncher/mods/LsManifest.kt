// app/src/main/java/com/lslauncher/mods/LsManifest.kt
package com.lslauncher.mods

import com.lslauncher.GameConfig
import org.json.JSONException
import org.json.JSONObject

class InvalidModException(message: String) : Exception(message)

data class InstallTarget(val source: String, val destination: String)

data class LsManifest(
    val id: String,
    val name: String,
    val version: String,
    val targets: List<InstallTarget>,
)

data class ModInfo(
    val manifest: LsManifest,
    val enabled: Boolean,
    val importedAtMillis: Long,
) {
    val id: String get() = manifest.id
    val name: String get() = manifest.name
}

object LsManifestParser {
    private val idPattern = Regex("^[a-z0-9][a-z0-9._-]{2,63}$")
    private const val MAX_TARGETS = 200
    private const val MAX_NAME_LENGTH = 64
    private const val MAX_VERSION_LENGTH = 32

    fun parse(jsonText: String, expectedTarget: String): LsManifest {
        val root = try {
            JSONObject(jsonText)
        } catch (e: JSONException) {
            throw InvalidModException("ls.json não é um JSON válido")
        }

        val format = root.optInt("format", -1)
        if (format != GameConfig.FORMAT_VERSION) {
            throw InvalidModException("Formato .ls não suportado (format=$format, esperado ${GameConfig.FORMAT_VERSION})")
        }

        val id = requireString(root, "id")
        if (!idPattern.matches(id)) {
            throw InvalidModException("id inválido: use 3 a 64 caracteres [a-z0-9._-]")
        }
        val name = requireString(root, "name")
        if (name.length > MAX_NAME_LENGTH) throw InvalidModException("name passa de $MAX_NAME_LENGTH caracteres")
        val version = requireString(root, "version")
        if (version.length > MAX_VERSION_LENGTH) throw InvalidModException("version passa de $MAX_VERSION_LENGTH caracteres")

        val target = requireString(root, "target")
        if (target != expectedTarget) {
            throw InvalidModException("Mod feito para $target, mas este launcher usa $expectedTarget")
        }

        return LsManifest(
            id = id,
            name = name,
            version = version,
            targets = parseTargets(root),
        )
    }

    private fun requireString(obj: JSONObject, key: String): String {
        if (!obj.has(key) || obj.isNull(key)) throw InvalidModException("Campo obrigatório ausente: $key")
        val value = obj.optString(key, "").trim()
        if (value.isEmpty()) throw InvalidModException("Campo vazio: $key")
        return value
    }

    private fun parseTargets(root: JSONObject): List<InstallTarget> {
        val array = root.optJSONArray("files")
            ?: throw InvalidModException("Campo 'files' ausente ou não é uma lista")
        if (array.length() == 0 || array.length() > MAX_TARGETS) {
            throw InvalidModException("'files' precisa ter de 1 a $MAX_TARGETS itens")
        }

        val targets = ArrayList<InstallTarget>(array.length())
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index)
                ?: throw InvalidModException("files[$index] não é um objeto")
            val source = normalizeRelativePath(requireString(item, "from"), "files[$index].from")
            val destination = normalizeRelativePath(requireString(item, "to"), "files[$index].to")

            val segments = destination.split('/')
            val root = segments.first()
            if (segments.size != 2 || root !in GameConfig.allowedDestinationRoots) {
                throw InvalidModException(
                    "Destino não permitido: $destination (use ${GameConfig.allowedDestinationRoots.joinToString("|")}/<nome>)"
                )
            }
            if (root in GameConfig.pngFileRoots && !destination.endsWith(".png")) {
                throw InvalidModException("Destino em $root precisa terminar em .png: $destination")
            }
            targets += InstallTarget(source, destination)
        }

        for (i in targets.indices) {
            for (j in i + 1 until targets.size) {
                val a = targets[i].destination
                val b = targets[j].destination
                if (a == b || a.startsWith("$b/") || b.startsWith("$a/")) {
                    throw InvalidModException("Destinos sobrepostos: $a e $b")
                }
            }
        }
        return targets
    }

    private fun normalizeRelativePath(raw: String, field: String): String {
        if (raw.contains('\\') || raw.startsWith("/")) {
            throw InvalidModException("$field precisa ser um caminho relativo com '/'")
        }
        val segments = raw.trimEnd('/').split('/')
        if (segments.any { it.isEmpty() || it == "." || it == ".." }) {
            throw InvalidModException("$field contém segmento inválido: $raw")
        }
        return segments.joinToString("/")
    }
}
