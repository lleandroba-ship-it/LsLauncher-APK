// app/src/main/java/com/lslauncher/mods/AtomicFile.kt
package com.lslauncher.mods

import java.io.File
import java.io.IOException

internal fun writeTextAtomically(target: File, text: String) {
    val parent = target.parentFile ?: throw IOException("Caminho sem diretório pai: $target")
    if (!parent.isDirectory && !parent.mkdirs()) throw IOException("Não foi possível criar $parent")
    val temporary = File(parent, "${target.name}.tmp")
    temporary.writeText(text, Charsets.UTF_8)
    if (!temporary.renameTo(target)) {
        temporary.delete()
        throw IOException("Não foi possível gravar ${target.name}")
    }
}
