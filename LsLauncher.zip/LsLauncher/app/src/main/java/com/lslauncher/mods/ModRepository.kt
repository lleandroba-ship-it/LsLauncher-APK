// app/src/main/java/com/lslauncher/mods/ModRepository.kt
package com.lslauncher.mods

import android.util.Log
import com.lslauncher.GameConfig
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException

class ModRepository(baseDirectory: File) {
    private data class ModState(val enabled: Boolean, val importedAtMillis: Long)

    private val modsDirectory = File(baseDirectory, "mods")
    private val stateFile = File(baseDirectory, "mods_state.json")
    private val lock = Any()

    fun modDirectory(id: String): File = File(modsDirectory, id)

    fun newStagingDirectory(): File {
        val staging = File(modsDirectory, ".staging-${System.nanoTime()}")
        if (!staging.mkdirs()) throw IOException("Não foi possível criar pasta temporária de importação")
        return staging
    }

    fun cleanLeftovers() {
        synchronized(lock) {
            modsDirectory.listFiles { file -> file.name.startsWith(".") }?.forEach { it.deleteRecursively() }
        }
    }

    fun list(): List<ModInfo> {
        synchronized(lock) {
            val states = readStates()
            val directories = modsDirectory.listFiles { file -> file.isDirectory && !file.name.startsWith(".") }
                ?: return emptyList()

            val mods = ArrayList<ModInfo>(directories.size)
            for (directory in directories) {
                val manifest = readManifest(directory) ?: continue
                val state = states[manifest.id]
                mods += ModInfo(
                    manifest = manifest,
                    enabled = state?.enabled ?: false,
                    importedAtMillis = state?.importedAtMillis ?: directory.lastModified(),
                )
            }
            return mods.sortedBy { it.name.lowercase() }
        }
    }

    /** Move a pasta já validada para o armazenamento definitivo. Mod novo entra LIGADO. */
    fun commit(stagingDirectory: File, manifest: LsManifest): ModInfo {
        synchronized(lock) {
            val target = modDirectory(manifest.id)
            val backup = File(modsDirectory, ".backup-${manifest.id}")
            backup.deleteRecursively()

            val hadPrevious = target.exists()
            if (hadPrevious && !target.renameTo(backup)) {
                throw IOException("Não foi possível substituir o mod existente")
            }
            if (!stagingDirectory.renameTo(target)) {
                if (hadPrevious) backup.renameTo(target)
                throw IOException("Não foi possível salvar o mod")
            }
            backup.deleteRecursively()

            val states = readStates().toMutableMap()
            val state = ModState(
                enabled = states[manifest.id]?.enabled ?: true,
                importedAtMillis = System.currentTimeMillis(),
            )
            states[manifest.id] = state
            writeStates(states)
            return ModInfo(manifest, state.enabled, state.importedAtMillis)
        }
    }

    fun setEnabled(id: String, enabled: Boolean): Boolean {
        synchronized(lock) {
            val directory = modDirectory(id)
            if (!directory.isDirectory) return false
            val states = readStates().toMutableMap()
            val previous = states[id]
            states[id] = ModState(enabled, previous?.importedAtMillis ?: directory.lastModified())
            return try {
                writeStates(states)
                true
            } catch (e: IOException) {
                Log.e(TAG, "Falha ao gravar estado do mod $id", e)
                false
            }
        }
    }

    fun delete(id: String): Boolean {
        synchronized(lock) {
            val states = readStates().toMutableMap()
            states.remove(id)
            val removedFiles = modDirectory(id).deleteRecursively()
            return try {
                writeStates(states)
                removedFiles
            } catch (e: IOException) {
                Log.e(TAG, "Falha ao gravar estado após apagar $id", e)
                false
            }
        }
    }

    private fun readManifest(directory: File): LsManifest? {
        val file = File(directory, GameConfig.MANIFEST_NAME)
        return try {
            LsManifestParser.parse(file.readText(Charsets.UTF_8), GameConfig.gamePackage)
        } catch (e: InvalidModException) {
            Log.w(TAG, "Mod ignorado (${directory.name}): ${e.message}")
            null
        } catch (e: IOException) {
            Log.w(TAG, "Mod ilegível (${directory.name}): ${e.message}")
            null
        }
    }

    private fun readStates(): Map<String, ModState> {
        if (!stateFile.isFile) return emptyMap()
        return try {
            val modsJson = JSONObject(stateFile.readText(Charsets.UTF_8)).getJSONObject("mods")
            val states = HashMap<String, ModState>()
            for (id in modsJson.keys()) {
                val entry = modsJson.getJSONObject(id)
                states[id] = ModState(entry.getBoolean("enabled"), entry.getLong("importedAt"))
            }
            states
        } catch (e: JSONException) {
            Log.w(TAG, "mods_state.json corrompido; mods voltam DESLIGADOS", e)
            emptyMap()
        } catch (e: IOException) {
            Log.w(TAG, "mods_state.json ilegível; mods voltam DESLIGADOS", e)
            emptyMap()
        }
    }

    private fun writeStates(states: Map<String, ModState>) {
        val modsJson = JSONObject()
        for ((id, state) in states) {
            modsJson.put(
                id,
                JSONObject().put("enabled", state.enabled).put("importedAt", state.importedAtMillis),
            )
        }
        writeTextAtomically(stateFile, JSONObject().put("mods", modsJson).toString())
    }

    private companion object {
        const val TAG = "ModRepository"
    }
}
