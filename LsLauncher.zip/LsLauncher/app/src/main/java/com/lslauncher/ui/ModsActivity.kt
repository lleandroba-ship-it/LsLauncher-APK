// app/src/main/java/com/lslauncher/ui/ModsActivity.kt
package com.lslauncher.ui

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.lslauncher.R
import com.lslauncher.databinding.ActivityModsBinding
import com.lslauncher.launcherApp
import com.lslauncher.mods.ImportResult
import com.lslauncher.mods.ModInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ModsActivity : ImmersiveActivity() {

    private lateinit var binding: ActivityModsBinding
    private lateinit var adapter: ModsAdapter
    private var importing = false

    private val pickModFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importMod(uri)
    }

    private val pickGameFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val saved = launcherApp.settings.saveGameFolder(uri)
            showBanner(getString(if (saved) R.string.msg_folder_saved else R.string.msg_folder_failed), isError = !saved)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityModsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ModsAdapter(onToggle = ::toggleMod, onDelete = ::confirmDelete)
        binding.modList.layoutManager = LinearLayoutManager(this)
        binding.modList.adapter = adapter

        binding.hotspotImport.setOnClickListener { startImport() }
        binding.importButton.setOnClickListener { startImport() }
        binding.folderButton.setOnClickListener { pickGameFolder.launch(null) }
        binding.hotspotExit.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun startImport() {
        if (importing) return
        // O seletor do Android não filtra por extensão; o filtro real é feito na validação.
        pickModFile.launch(arrayOf("*/*"))
    }

    private fun importMod(uri: Uri) {
        importing = true
        showBanner(getString(R.string.msg_importing), isError = false)
        lifecycleScope.launch {
            try {
                when (val result = withContext(Dispatchers.IO) { launcherApp.importer.import(uri) }) {
                    is ImportResult.Success -> showBanner(
                        "${getString(R.string.import_success)}\n${result.mod.name}",
                        isError = false,
                        isSuccess = true,
                    )
                    is ImportResult.Failure -> showBanner(
                        "${getString(R.string.import_error)}\n${result.reason}",
                        isError = true,
                    )
                }
                refreshList()
            } finally {
                importing = false
            }
        }
    }

    private fun toggleMod(mod: ModInfo) {
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) { launcherApp.repository.setEnabled(mod.id, !mod.enabled) }
            if (!saved) showBanner(getString(R.string.msg_toggle_failed), isError = true)
            refreshList()
        }
    }

    private fun confirmDelete(mod: ModInfo) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, mod.name))
            .setPositiveButton(R.string.action_delete) { _, _ -> deleteMod(mod) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteMod(mod: ModInfo) {
        lifecycleScope.launch {
            val deleted = withContext(Dispatchers.IO) { launcherApp.repository.delete(mod.id) }
            if (!deleted) showBanner(getString(R.string.msg_delete_failed), isError = true)
            refreshList()
        }
    }

    private fun refreshList() {
        lifecycleScope.launch {
            val mods = withContext(Dispatchers.IO) { launcherApp.repository.list() }
            adapter.submitList(mods)
            binding.listPanel.isVisible = mods.isNotEmpty()
            binding.hotspotImport.isVisible = mods.isEmpty()
        }
    }

    private fun showBanner(text: String, isError: Boolean, isSuccess: Boolean = false) {
        val color = when {
            isError -> R.color.message_error
            isSuccess -> R.color.message_ok
            else -> R.color.message_info
        }
        binding.messageText.setTextColor(ContextCompat.getColor(this, color))
        binding.messageText.text = text
        binding.messageText.isVisible = true
    }
}
