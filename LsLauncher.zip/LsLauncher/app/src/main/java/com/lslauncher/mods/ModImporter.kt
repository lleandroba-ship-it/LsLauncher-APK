// app/src/main/java/com/lslauncher/mods/ModImporter.kt
package com.lslauncher.mods

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.lslauncher.GameConfig
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipException
import java.util.zip.ZipInputStream

sealed interface ImportResult {
    data class Success(val mod: ModInfo) : ImportResult
    data class Failure(val reason: String) : ImportResult
}

class ModImporter(private val context: Context, private val repository: ModRepository) {

    /** Valida o arquivo .ls inteiro antes de qualquer coisa ser registrada como instalada. */
    fun import(uri: Uri): ImportResult {
        var staging: File? = null
        try {
            val displayName = queryDisplayName(uri)
            if (displayName == null || !displayName.endsWith(GameConfig.MOD_EXTENSION, ignoreCase = true)) {
                throw InvalidModException("Selecione um arquivo com extensão ${GameConfig.MOD_EXTENSION}")
            }

            val directory = repository.newStagingDirectory()
            staging = directory
            extractArchive(uri, directory)
            val manifest = readManifest(directory)
            verifyTargets(directory, manifest)
            return ImportResult.Success(repository.commit(directory, manifest))
        } catch (e: InvalidModException) {
            return ImportResult.Failure(e.message ?: "Mod inválido")
        } catch (e: ZipException) {
            return ImportResult.Failure("Arquivo corrompido ou não é um ZIP válido")
        } catch (e: IOException) {
            return ImportResult.Failure("Falha de leitura/gravação: ${e.message}")
        } catch (e: SecurityException) {
            return ImportResult.Failure("Sem permissão para ler o arquivo escolhido")
        } finally {
            staging?.deleteRecursively()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (column >= 0) return cursor.getString(column)
            }
        }
        return uri.lastPathSegment
    }

    private fun extractArchive(uri: Uri, destination: File) {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw InvalidModException("Não foi possível abrir o arquivo")
        val destinationRoot = destination.canonicalPath + File.separator

        ZipInputStream(BufferedInputStream(input)).use { zip ->
            var entryCount = 0
            var unpackedBytes = 0L
            val buffer = ByteArray(16 * 1024)

            while (true) {
                val entry = zip.nextEntry ?: break
                entryCount++
                if (entryCount > GameConfig.MAX_ARCHIVE_ENTRIES) {
                    throw InvalidModException("Arquivo com entradas demais (máx. ${GameConfig.MAX_ARCHIVE_ENTRIES})")
                }

                val output = File(destination, entry.name)
                if (!output.canonicalPath.startsWith(destinationRoot)) {
                    throw InvalidModException("Entrada insegura no arquivo: ${entry.name}")
                }
                if (entry.isDirectory) {
                    output.mkdirs()
                    continue
                }

                val parent = output.parentFile ?: throw InvalidModException("Entrada inválida: ${entry.name}")
                if (!parent.isDirectory && !parent.mkdirs()) throw IOException("Não foi possível criar ${parent.name}")

                FileOutputStream(output).use { sink ->
                    while (true) {
                        val read = zip.read(buffer)
                        if (read < 0) break
                        unpackedBytes += read
                        if (unpackedBytes > GameConfig.MAX_UNPACKED_BYTES) {
                            throw InvalidModException("Mod grande demais depois de descompactado")
                        }
                        sink.write(buffer, 0, read)
                    }
                }
            }
        }
    }

    private fun readManifest(directory: File): LsManifest {
        val file = File(directory, GameConfig.MANIFEST_NAME)
        if (!file.isFile) {
            throw InvalidModException("${GameConfig.MANIFEST_NAME} não encontrado na raiz (o .ls precisa ser um ZIP com esse arquivo)")
        }
        if (file.length() > GameConfig.MAX_MANIFEST_BYTES) {
            throw InvalidModException("${GameConfig.MANIFEST_NAME} grande demais")
        }
        return LsManifestParser.parse(file.readText(Charsets.UTF_8), GameConfig.gamePackage)
    }

    private fun verifyTargets(directory: File, manifest: LsManifest) {
        for (target in manifest.targets) {
            val source = File(directory, target.source)
            if (!source.exists()) {
                throw InvalidModException("Arquivo declarado não existe no mod: ${target.source}")
            }
            val destinationRoot = target.destination.substringBefore('/')
            if (destinationRoot in GameConfig.packRoots) {
                if (!source.isDirectory) {
                    throw InvalidModException("'${target.source}' deve ser uma pasta de pacote")
                }
                if (!File(source, GameConfig.PACK_MANIFEST_NAME).isFile) {
                    throw InvalidModException("Pacote sem ${GameConfig.PACK_MANIFEST_NAME}: ${target.source}")
                }
            }
        }
    }
}
