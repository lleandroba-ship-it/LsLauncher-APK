// app/src/main/java/com/lslauncher/ui/MainActivity.kt
package com.lslauncher.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.lslauncher.GameConfig
import com.lslauncher.R
import com.lslauncher.databinding.ActivityMainBinding
import com.lslauncher.launcherApp
import com.lslauncher.mods.GameSyncException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ImmersiveActivity() {

    private sealed interface PlayOutcome {
        object Ready : PlayOutcome
        object NeedsGameFolder : PlayOutcome
        data class Failed(val reason: String) : PlayOutcome
    }

    private lateinit var binding: ActivityMainBinding
    private var busy = false

    private val pickGameFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val saved = launcherApp.settings.saveGameFolder(uri)
            showMessage(
                getString(if (saved) R.string.msg_folder_saved else R.string.msg_folder_failed),
                isError = !saved,
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.hotspotPlay.setOnClickListener { onPlayClicked() }
        binding.hotspotMods.setOnClickListener {
            if (!busy) startActivity(Intent(this, ModsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCounter()
    }

    private fun refreshCounter() {
        lifecycleScope.launch {
            val mods = withContext(Dispatchers.IO) { launcherApp.repository.list() }
            val enabledCount = mods.count { it.enabled }
            val onLine = if (enabledCount == 1) {
                getString(R.string.counter_on_one)
            } else {
                getString(R.string.counter_on_other, enabledCount)
            }
            val summaryLine = getString(R.string.counter_summary, mods.size - enabledCount, mods.size)
            binding.counterText.text = "$onLine\n$summaryLine"
        }
    }

    private fun onPlayClicked() {
        if (busy) return
        setBusy(true)
        showMessage(getString(R.string.msg_preparing), isError = false)

        lifecycleScope.launch {
            try {
                when (val outcome = withContext(Dispatchers.IO) { prepareMods() }) {
                    PlayOutcome.Ready -> {
                        binding.messageText.isVisible = false
                        launchGame()
                    }
                    PlayOutcome.NeedsGameFolder -> {
                        showMessage(getString(R.string.msg_need_folder), isError = true)
                        pickGameFolder.launch(launcherApp.settings.folderPickerHint())
                    }
                    is PlayOutcome.Failed -> {
                        showMessage(getString(R.string.msg_prepare_error, outcome.reason), isError = true)
                    }
                }
            } finally {
                setBusy(false)
            }
        }
    }

    /** Sincroniza a pasta do jogo com os mods LIGADOS. Sem mods e sem resíduos, não toca em nada. */
    private fun prepareMods(): PlayOutcome {
        val app = launcherApp
        val enabledMods = app.repository.list().filter { it.enabled }
        if (enabledMods.isEmpty() && !app.gameSync.hasInstalledMods()) return PlayOutcome.Ready

        val gameFolder = app.settings.writableGameFolder() ?: return PlayOutcome.NeedsGameFolder
        return try {
            app.gameSync.sync(gameFolder, enabledMods)
            PlayOutcome.Ready
        } catch (e: GameSyncException) {
            PlayOutcome.Failed(e.message ?: "falha desconhecida")
        }
    }

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage(GameConfig.gamePackage)
        if (intent == null) {
            showMessage(getString(R.string.msg_game_missing, GameConfig.gamePackage), isError = true)
            return
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            showMessage(getString(R.string.msg_game_missing, GameConfig.gamePackage), isError = true)
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.hotspotPlay.isEnabled = !value
        binding.hotspotMods.isEnabled = !value
    }

    private fun showMessage(text: String, isError: Boolean) {
        val color = if (isError) R.color.message_error else R.color.message_info
        binding.messageText.setTextColor(ContextCompat.getColor(this, color))
        binding.messageText.text = text
        binding.messageText.isVisible = true
    }
}
