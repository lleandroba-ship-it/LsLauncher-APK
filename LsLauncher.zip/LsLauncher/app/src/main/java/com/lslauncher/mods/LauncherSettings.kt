// app/src/main/java/com/lslauncher/mods/LauncherSettings.kt
package com.lslauncher.mods

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import com.lslauncher.GameConfig

class LauncherSettings(private val context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun saveGameFolder(uri: Uri): Boolean {
        return try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
            preferences.edit().putString(KEY_GAME_FOLDER, uri.toString()).commit()
        } catch (e: SecurityException) {
            Log.w(TAG, "Permissão persistente negada para $uri", e)
            false
        }
    }

    /** Pasta inicial sugerida no seletor: Android/data/<jogo>/files. */
    fun folderPickerHint(): Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents",
        "primary:Android/data/${GameConfig.gamePackage}/files",
    )

    /** Retorna a pasta do jogo somente se a permissão de leitura e escrita ainda estiver válida. */
    fun writableGameFolder(): Uri? {
        val stored = preferences.getString(KEY_GAME_FOLDER, null)?.let(Uri::parse) ?: return null
        val granted = context.contentResolver.persistedUriPermissions.any {
            it.uri == stored && it.isReadPermission && it.isWritePermission
        }
        return if (granted) stored else null
    }

    private companion object {
        const val TAG = "LauncherSettings"
        const val PREFERENCES_NAME = "ls_launcher"
        const val KEY_GAME_FOLDER = "game_folder_uri"
    }
}
