// app/src/main/java/com/lslauncher/GameConfig.kt
package com.lslauncher

object GameConfig {
    val gamePackage: String = BuildConfig.GAME_PACKAGE

    const val MANIFEST_NAME = "ls.json"
    const val MOD_EXTENSION = ".ls"
    const val FORMAT_VERSION = 1

    const val MAX_ARCHIVE_ENTRIES = 20_000
    const val MAX_UNPACKED_BYTES = 512L * 1024 * 1024
    const val MAX_MANIFEST_BYTES = 1L * 1024 * 1024

    // Pastas que o Lost Miner realmente lê em Android/data/<pacote>/files/
    const val TEXTURE_PACKS_ROOT = "texture_packs"
    const val TEXTURE_PACK_INFO_FILE = "info.txt"
    val pngFileRoots: Set<String> = setOf("custom_skins", "custom_controls")
    val allowedDestinationRoots: Set<String> = pngFileRoots + TEXTURE_PACKS_ROOT
}
