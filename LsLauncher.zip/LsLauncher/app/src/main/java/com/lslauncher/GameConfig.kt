// app/src/main/java/com/lslauncher/GameConfig.kt
package com.lslauncher

object GameConfig {
    val gamePackage: String = BuildConfig.GAME_PACKAGE

    const val MANIFEST_NAME = "ls.json"
    const val MOD_EXTENSION = ".ls"
    const val FORMAT_VERSION = 1

    const val MAX_ARCHIVE_ENTRIES = 20_000
    const val MAX_UNPACKED_BYTES = 512L * 1024 * 1024
    const val MAX_MANIFEST_BYTES = 1L * 1024 * 1024

    // Pastas do jogo em que um mod pode escrever (relativas a games/com.mojang).
    val packRoots: Set<String> = setOf("behavior_packs", "resource_packs", "skin_packs")
    val allowedDestinationRoots: Set<String> = packRoots + "world_templates"

    const val PACK_MANIFEST_NAME = "manifest.json"
    const val GLOBAL_RESOURCE_PACKS_PATH = "minecraftpe/global_resource_packs.json"
}
