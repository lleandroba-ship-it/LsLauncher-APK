# LS Launcher

Launcher Android para jogo com gerenciador de mods `.ls`. Telas: principal (JOGAR / MODS + contador) e MODS (importar, ligar/desligar, apagar). Funciona offline.

## Build
- GitHub: suba o projeto, aba **Actions → Build APK → Artifacts → LsLauncher-debug-apk**.
- Local: `gradle assembleDebug` (JDK 17, Gradle 8.7+). Outro jogo: `-PgamePackage=com.outro.jogo`.

## Formato `.ls`
ZIP com `ls.json` na raiz:

```json
{
  "format": 1,
  "id": "meu.mod",
  "name": "Meu Mod",
  "version": "1.0.0",
  "target": "com.mojang.minecraftpe",
  "files": [{ "from": "pack", "to": "resource_packs/meu_mod" }],
  "globalResourcePacks": [{ "pack_id": "<uuid>", "version": [1, 0, 0] }]
}
```

- `target` precisa ser o pacote do jogo configurado no launcher.
- `to` só pode começar por `behavior_packs/`, `resource_packs/`, `skin_packs/` ou `world_templates/`.
- Pastas em `behavior_packs|resource_packs|skin_packs` precisam ter `manifest.json`.
- `globalResourcePacks` (opcional) registra o pacote em `minecraftpe/global_resource_packs.json`.
- Gerar: `python3 tools/make_ls.py samples/hello_pack samples/hello_pack.ls`.

## Como os mods chegam ao jogo
1. Importar valida o ZIP (zip-slip, tamanho, `ls.json`, caminhos, `target`). Inválido = ERRO AO IMPORTAR e nada é registrado.
2. Em MODS → **PASTA DO JOGO**, escolha uma vez a pasta `games/com.mojang` do jogo.
3. Em JOGAR, o launcher copia os mods LIGADOS para essa pasta, remove os DESLIGADOS/apagados que instalou antes, e abre o jogo. Sem mods ligados, abre o jogo limpo.
4. O APK do jogo nunca é alterado. Arquivos que não são do launcher nunca são sobrescritos (o sync aborta com erro).

## Limite do Android
O acesso à pasta do jogo é via Storage Access Framework. Em Android 11+ a pasta `Android/data` é bloqueada para seleção; funciona onde `games/com.mojang` está em armazenamento acessível (ex.: `/sdcard/games/com.mojang`). Behavior packs ainda precisam ser ativados no mundo dentro do jogo.
