# LS Launcher (Lost Miner)

Launcher Android para o **Lost Miner** (`com.fsilva.marcelo.lostminer`) com gerenciador de mods `.ls`. Funciona offline.

## Build
- GitHub: suba o projeto, aba **Actions → Build APK → Artifacts → LsLauncher-debug-apk**.
- Local: `gradle assembleDebug` (JDK 17, Gradle 8.7+). Outro jogo: `-PgamePackage=com.outro.jogo`.

## O que um mod pode ser
O Lost Miner lê de `Android/data/com.fsilva.marcelo.lostminer/files/`:
- `texture_packs/<nome>/` (precisa de `info.txt`; também `terrain.png`, `itens.png`, `text_icon.png`, ...)
- `custom_skins/<nome>.png`
- `custom_controls/<nome>.png`

Mod de código (que muda a lógica do jogo) não é possível sem modificar o APK do jogo, o que o launcher não faz.

## Formato `.ls`
ZIP com `ls.json` na raiz:

```json
{
  "format": 1,
  "id": "meu.mod",
  "name": "Meu Mod",
  "version": "1.0.0",
  "target": "com.fsilva.marcelo.lostminer",
  "files": [{ "from": "pack", "to": "texture_packs/meu_mod" }]
}
```

Gerar: `python3 tools/make_ls.py samples/joli_texture samples/joli_texture.ls`

## Como os mods chegam ao jogo
1. Importar valida o ZIP. Inválido = ERRO AO IMPORTAR e nada é registrado.
2. Em MODS → **PASTA DO JOGO**, escolha `Android/data/com.fsilva.marcelo.lostminer/files` e toque em "Usar esta pasta".
3. Em JOGAR, o launcher copia os mods LIGADOS, remove os DESLIGADOS/APAGADOS que instalou antes e abre o Lost Miner. Sem mods ligados, abre o jogo limpo.
4. Dentro do jogo, ative o texture pack/skin no menu correspondente.

## Limite do Android
Em Android 13 ou superior o sistema bloqueia a seleção de `Android/data`. Em Android 11 e 12 o seletor costuma abrir já na pasta certa.
